<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_login extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Userlogin_model');
        $this->load->library('form_validation');
        $this->load->library('session');
    }

    public function index()
    { 
        $res = array();
            if($this->session->userdata('user_id'))
            {
                //redirect('admin/Dashbord/index');
            }
            if($this->input->post('submit'))
            {
                $emailid=$this->input->post('email_id');
                $password=$this->input->post('password');
                //print_r($this->input->post());
                $check_login=$this->Userlogin_model->check_user($emailid,$password);
                //redirect('admin/dashbord');
                $num=$check_login->num_rows();
                //print_r($num);
                if($num==1)     
                {
                    $row=$check_login->row_array(); //print_r($row);
                    $this->session->set_userdata('user_id',$row['user_id']);
                    $this->session->set_userdata('email_id',$row['email_id']);
                    $this->session->set_userdata('password',$row['password']);
                    //echo '<pre>'; print_r($this->session->userdata('user_id'));exit;
                    redirect('Home');
                }
                else
                {
                    $res = array(
                        'status' => "fail",
                        'message' => "Login fail"
                    );
                }
                
            }
    }

    public function user_registration()
    {
        $data=array();
            
        if($this->input->post('submit'))
        {
            $f_name = $this->input->post('f_name');
            $l_name = $this->input->post('l_name');
            $company_name = $this->input->post('company_name');
            $address = $this->input->post('address');
            $country = $this->input->post('country');
            $state = $this->input->post('state');
            $city = $this->input->post('city');
            $zip = $this->input->post('zip');
            $email_id = $this->input->post('email_id');
            $password = $this->input->post('password');
            $phone_no = $this->input->post('phone_no');

           // print_r($this->input->post());
            
            $this->form_validation->set_rules('f_name','First Name','required');
            $this->form_validation->set_rules('l_name','Last Name','required');
            $this->form_validation->set_rules('company_name','Company Name','required');
            $this->form_validation->set_rules('address','Address','required');
            $this->form_validation->set_rules('country','Country','required');
            $this->form_validation->set_rules('state','State','required');
            $this->form_validation->set_rules('city','City','required');
            $this->form_validation->set_rules('zip','Zip','required');
            $this->form_validation->set_rules('email_id','Email','required|valid_email');
            $this->form_validation->set_rules('password','Password','required|min_length[8]|max_length[8]');
            $this->form_validation->set_rules('phone_no','Phone','required|min_length[10]|max_length[10]|numeric');

            if($this->form_validation->run()==FALSE)
            { //echo 'hi';
                $res = array(
                    'status' => "fail",
                    'message' => "registration fail"
                );

            }else{
                $data = array(
                    'f_name' => $f_name,
                    'l_name' => $l_name,
                    'company_name' => $company_name,
                    'address' => $address,
                    'country' => $country,
                    'state' => $state,
                    'city' => $city,
                    'zip' => $zip,
                    'email_id' => $email_id,
                    'password' => $password,
                    'phone_no' => $phone_no
                );
                //print_r($data); exit;
                $this->Userlogin_model->registration_insertdata($data);
                redirect('Home/login');
            }
        }
    } 

}