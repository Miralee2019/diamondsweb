<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/bootstrap.min.css">
        <script src="<?php echo base_url(); ?>assets/home/js/jquery.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/home/js/popper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/home/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="assets/aboutus/css/about.css">
    </head>
    <body>
    <?php //include 'header.php';?>
    <!-- <div id="header"></div> -->
    <?php //include 'mobile_header.php';?>
    <!-- <div id="mobile_header"></div> -->
        <div class="jumbotron text-center" style="background-image:url('<?php echo base_url(); ?>assets/aboutus/images/backimage.JPG');">
            <!-- <img src="<?php echo base_url('assets/aboutus/images/backimage.jpg'); ?>"> -->
        </div>  
        <div class="container">
            <div class="about_info">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12 desc">
                        <div class="about_desc">
                            <h3>We Believe in...</h3>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 imgs">
                        <div class="about_img">
                            <img src="<?php echo base_url();?>assets/aboutus/images/about-img1.jpg" alt="diamond" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include 'footer.php';?>
    <!-- <div id="footer"></div> -->
    </body>
</html>