<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/checkout/css/checkout.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/w3.css">
    
</head>

<body>

<?php //include 'header.php';?>
    <!-- <div id="header"></div> -->
    <?php //include 'mobile_header.php';?>
    <!-- <div id="mobile_header"></div> -->

    <div class="heading">
        <h4>Checkout</h4>
    </div>
    <div class="container">
        <div class="accordion" id="accordionExample">
            <div class="card z-depth-0 bordered">
                <div class="card-header" id="headingTwo">
                    <p>Have a coupon?</p>
                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                        data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        Click here to enter your code
                    </button>
                </div>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <div class="card-body clearfix">
                        <div style="height: 30px;">
                            <p>If you have a coupon code, please apply it below.</p>
                        </div>
                        <div class="coupon_code">
                            <input type="text" class="form-control" aria-describedby="couponHelp"
                                placeholder="Coupon Code">
                        </div>
                        <button class="btn btn_code">
                            APPLY COUPON
                        </button>
                    </div>
                </div>
            </div>
            <div class="card z-depth-0 bordered">
                <div class="card-header" id="headingThree">
                    <p>Shipment will be traceable, In Free Shipping you will receive delivery in 13-15 days,while in
                        Fast Delivery Product will be delivered in 4-6 days</p>
                </div>
            </div>
        </div>
        <div class="row checkout_form">
            <div class="col-xl-6 billing_details clearfix">
                <h4 class="h5">Billing Details</h4>
                <form action="" method="post">
                    <div class="sign-up-form">
                        <div class="group fname">
                            <label for="fname" class="label">First Name</label> 
                            <input id="fname" name="fname" type="text" class="input" placeholder="Create your Firstname">
                            <label style="color: red"><?php echo form_error('fname'); ?></label>
                        </div>

                        <div class="group lname">
                            <label for="lname" class="label">Last Name</label> 
                            <input id="lname" name="lname" type="text" class="input" placeholder="Create your Lastname">
                            <label style="color: red"><?php echo form_error('lname'); ?></label>
                        </div>

                        <div class="group email">
                            <label for="email" class="label">Email Address</label> 
                            <input id="email" name="email_id" type="text" class="input" placeholder="Enter your email address">
                            <label style="color: red"><?php echo form_error('email_id'); ?></label>
                        </div>

                        <!-- <div class="group">
                                <label for="pass" class="label">Password</label> <input id="pass" type="password" class="input" data-type="password" placeholder="Create your password">
                            </div> -->
                        <div class="group phone">
                            <label for="phone" class="label">Phone No.</label> 
                            <input id="phone" name="phone_no" type="text" class="input" placeholder="Enter your phone number">
                            <label style="color: red"><?php echo form_error('phone_no'); ?></label>
                        </div>
                        <!-- <div class="group country">
                            <label for="country" class="label">Country</label>
                            <select id="country" name="country" class="input" placeholder="Choose Country">
                                            <option>Select country</option>
                                            <?php foreach($Countries as $row){ ?>
                                                <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
                                            <?php } ?>
                                        </select>
                                        <label style="color: red"><?php echo form_error('country'); ?></label>
                        </div> -->
                        <div class="group country">
                            <label for="country" class="label">Country</label> 
                            <input id="country" name="country" type="text" class="input" placeholder="Enter your Country name">
                            <label style="color: red"><?php echo form_error('country'); ?></label>
                        </div>     

                        <div class="group state">
                            <label for="State" class="label">State</label> 
                            <input id="state-name" name="state" type="text" class="input" placeholder="Enter your State name">
                            <label style="color: red"><?php echo form_error('state'); ?></label>
                        </div>             
                        <!-- <div class="group state">
                            <label for="State" class="label">State</label>
                            <select id="state-name" name="state" class="input" placeholder="Choose State">
                            </select>
                            <label style="color: red"><?php echo form_error('state'); ?></label>
                        </div>

                        <div class="group city">
                            <label for="City" class="label">City</label>
                            <select id="city-name" name="city" class="input" placeholder="Choose City">
                            </select>
                            <label style="color: red"><?php echo form_error('city'); ?></label>
                        </div> -->

                        <div class="group city">
                            <label for="City" class="label">City</label> 
                            <input id="city-name" name="city" type="text" class="input" placeholder="Enter your City name">
                            <label style="color: red"><?php echo form_error('city'); ?></label>
                        </div>    

                        <div class="group address">
                            <label for="address" class="label">Address</label> 
                            <textarea id="address" name="address" type="text" rows="1" class="input" placeholder="Enter your Address"></textarea>
                            <label style="color: red"><?php echo form_error('address'); ?></label>
                        </div>

                        <div class="group company">
                            <label for="company" class="label">Comapny Name</label> 
                            <input id="company" name="company" type="text" class="input" placeholder="Enter your Company name">
                            <label style="color: red"><?php echo form_error('company'); ?></label>
                        </div>
                        <div class="group zip">
                            <label for="zip" class="label">Zip Code</label> 
                            <input id="zip" name="zip" type="text" class="input" placeholder="Enter your Zip code">
                            <label style="color: red"><?php echo form_error('zip'); ?></label>
                        </div>
                        <!-- <div class="group">
                                <label for="pass" class="label">Repeat Password</label> <input id="pass" type="password" class="input" data-type="password" placeholder="Repeat your password">
                            </div> -->
                        <div class="group button">
                            <a href=""><input type="submit" name="submit" id="paypal" class="button" value="Payment with PayPal"></a>
                        </div>
                        <div class="hr"></div>
                        <div class="foot"> <label for="tab-1">Already Member?</label> </div>
                    </div>
                </form>
            </div>
            <div class="col-xl-6 your_order">
                <h4 class="h5">Your order</h4>
                <table class="table table-bordered">
                    <th>Product</th>
                    <th>Subtotal</th>
                    <?php //print_r($productvariation); 
                     $total_sum = 0; 
                     foreach($productvariation as $product){ //print_r($product); ?>
                        <tr>
                            <input type="hidden" id="user_id" value="<?php echo $product['user_id']; ?>">
                            <td><?php echo $product['pname']; ?></td>
                            <?php $total = $product['price']*$product['quantity'];?>
                            <td>$<?php echo $total; ?></td>
                        </tr>
                    <?php $total_sum += $total;} ?>
                    <tr>
                        <th>Subtotal</th>
                        <input type="hidden" id="sub_total" value="<?php echo $total_sum; ?>">
                        <td>$<?php echo $total_sum; ?></td>
                    </tr>
                    <!-- <tr>
                        <th>SHIPPING</th>
                        <td>
                            <div class="form-check">
                                <input type="radio" class="form-check-input" id="radio1" name="optradio" value="option1"
                                    checked><p>Fast Shipping (Estimate 6 - 10 days):$40.00</p>
                            </div>
                            <div class="form-check">
                                <input type="radio" class="form-check-input" id="radio2" name="optradio"
                                    value="option2"><p>Standard Shipping ( Estimate 13 - 15 Days:$20.00</p>
                            </div>
                        </td>
                    </tr> -->
                    <tr>
                            <th>Shipping</th>
                            <td>
                            <?php foreach($shipping as $key=>$row){ //print_r($row);?>
                                <div class="form-check">
                                    <input type="hidden" id="shipping_id" value="<?php echo $row['shipping_id']; ?>">
                                    <input type="radio" data-sum="<?php echo $total_sum; ?>" data-rate="<?php echo $row['shipping_rate']; ?>" class="form-check-input" id="shipping" name="optradio" value="<?php echo $row['shipping_id']; ?>"
                                        <?php //if($key == 0){ echo "checked"; } ?>><?php echo $row['shipping_name']; ?>:<p> $<?php echo $row['shipping_rate']; ?></p>
                                </div>
                                <?php } ?>
                                <p>Shipping to <strong>Gujarat.</strong></p>
                                <a href="">Change address</a>
                            </td>
                        </tr>
                    <tr>
                        <th>Total</th>
                        <form method="get">
                        <input type="hidden" name="hidden" value="<?php echo $total_sum; ?>">
                        </form>
                        <td id="subtotal"><?php echo '$'.$total_sum; ?><?php //echo '$'.$total_sum+40; ?></td>
                    </tr>
                </table>
                <div class="payment">
                    <h6 class="h6">PayPal</h6>
                    <div class="pay_img">
                        <img src="<?php echo base_url(); ?>assets/checkout/images/payment.webp">
                    </div>
                    <p class="paypal_info">
                        <a href="https://www.paypal.com/in/webapps/mpp/home">what is PayPal?</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer.php';?>
    <!-- <div id="footer"></div> -->
    <p>
        <div class="whatsapp">
            <a href="https://api.whatsapp.com/send?phone=91----------" target="_blank">
                <h5>
                    <i class="fa fa-whatsapp fa-3x " aria-hidden="true"></i>
                </h5>
            </a>
        </div>
    </p>

    <script src="<?php echo base_url(); ?>assets/home/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>js/jQuery/jquery.monte.js"></script>
    <script src="<?php echo base_url(); ?>assets/home/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/home/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/checkout/js/checkout.js"></script>
    <script src="<?php echo base_url(); ?>assets/home/js/script.js"></script>
</body>

</html>
<script type="text/javascript">
    $(document).ready(function(){
    
    $(".form-check input").click(function(){
       var rate = $(this).attr("data-rate");
       var sum = $(this).attr("data-sum");
       var subtotal = parseInt(rate) + parseInt(sum);
       //alert(total);
       $.ajax({  
                url:"<?php echo site_url('Billing/order'); ?>",  
                method:"POST",  
                data:{subtotal:subtotal},  
                success:function(data){  
                     //alert(data);
                }  
           });  
       document.getElementById("subtotal").innerHTML = '$'+subtotal;
    });

    $("#paypal").click(function(){
        var user_id = $("#user_id").val();
        var shipping_id = $("#shipping_id").val();
        var sub_total = $("#sub_total").val();
        $.ajax({  
                url:"<?php echo site_url('Billing/orderdata_insert'); ?>",  
                method:"POST",  
                data:{user_id:user_id,shipping_id:shipping_id,sub_total:sub_total},  
                success:function(data){  
                     //alert(data);
                }  
           }); 
    });
});
</script>

<!-- <script type="text/javascript">
// 		$(document).ready(function(e)
// 		{
// 			$('#country').on('change',function()
// 			{ 
// 				var countryID=$(this).val();		
// 				if(countryID)
// 				{
// 					$.ajax({type:'POST',
//                                         url:'<?php  echo site_url('Home/getstates')?>',
//                                         data:'id='+countryID,
//                                         success:function(html)
//                                         {
//                                                 $('#state-name').html(html);
//                                         }
// 					});	
// 				}
//             });
            
//             $('#state-name').on('change',function()
// 			{ 
// 				var stateID=$(this).val();		
// 				if(stateID)
// 				{
// 					$.ajax({type:'POST',
//                                         url:'<?php  echo site_url('Home/getcities')?>',
//                                         data:'id='+stateID,
//                                         success:function(html)
//                                         {
//                                                 $('#city-name').html(html);
//                                         }
// 					});	
// 				}
// 			});
// 		});
// 	</script> -->