<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/cart/css/cart.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/w3.css">
    
</head>

<body>
    <?php include 'header.php';?>
    <!-- <div id="header"></div> -->
    <?php include 'mobile_header.php';?>
    <!-- <div id="mobile_header"></div> -->

    <div class="cart_breadcrumb">
        <h1>Cart</h1>
    </div>
    <div class="container container-lg container-md container-sm container-xl" style="padding: 0; margin: 0 auto;">
        <div class="cart_details">
            <?php if($this->session->userdata('user_id')) { ?>
            <table class="table table-responsive">
                <tr>
                    <th></th>
                    <th></th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
                <?php if($cart != null) { ?>
                <?php foreach($cart as $data){  $img = explode(',',$data['image']); ?>
                <tr>
                    <td><a href="<?php echo base_url('index.php/Product/delete_cart/'.$data['cart_id']); ?>"><i style="font-size:24px" class="fa">&#xf00d;</i></a></td>
                    <td class="pro_img"><img src="<?php echo base_url('assets/images/'.$img['1']); ?>"></td>
                    <td class="pro_title">
                        <p><?php echo $data['pname']; ?></p>
                    </td>
                    <td class="pro_total">
                        <p>$<?php echo $data['price']; ?></p>
                    </td>
                    <td>
                        <input type="hidden" id="hidden" value="<?php echo $data['product_id']; ?>">
                        <input type="hidden" id="price" value="<?php echo $data['price']; ?>">
                        <?php if($data['stock'] == 0) {?>
                        <input class="quantity" type="number" name="quantity" value="0" id="quantity" name="quantity" min="0" max="0" disabled>
                        <?php }else { ?>
                        <input type="number" id="quantity" name="quantity" class="quantity" value="<?php echo $data['quantity']; ?>" min="1"
                            title="Qty" max="<?php echo $data['stock']; ?>" size="4" placeholder="" inputmode="numeric">
                        <?php } ?>
                    </td>
                    <td class="pro_subtotal"><?php $total = $data['price']*$data['quantity'];?>
                        <p id="total">$<?php echo $total;?></p>
                    </td>
                </tr>
                <?php } ?>
                <tr>
                    <td colspan="6">
                        <div class="btn_content">
                            <input type="text" class="form-control" aria-describedby="couponHelp"
                                placeholder="Coupon Code">
                            <button class="btn btn-coupon">APPLY COUPON</button>
                            <!-- <button id="update" class="btn btn-update_cart">UPDATE CART</button> -->
                            <a href="<?php echo base_url('index.php/Billing/checkout/'.$data['user_id']); ?>">
                            <button id="update" class="btn btn-update_cart">PROCEED TO CHECKOUT</button></a>
                        </div>
                    </td>
                </tr>
                <?php } else { ?>
                <h2>Data not found...</h2>
                <?php } ?>
            </table>
            <?php } else { ?>
            <h3>Data not found...</h3>
            <?php } ?>
        </div>
        <!-- <div class="row cart_subtotal">
            <div class="col-xl-6 col-sm-0 col-md-0" style="padding: 0;"></div>
                <div class="col-xl-6 col-md-12 col-sm-12 col-12 table_content" style="padding: 0;">
                    <div class="heading">
                        <h4>Cart totals</h4>
                    </div>
                    <table class="table table-responsive">
                        <tr>
                            <th>Subtotal</th><?php $total_sum = 0; foreach($cart as $data){ $total_sum += $data['price'];} ?>
                            <td>$<?php echo $total_sum; ?></td>
                        </tr>
                        <tr>
                            <th>Shipping</th>
                            <td>
                            <?php foreach($shipping as $row){ //print_r($row);?>
                                <div class="form-check">
                                    <input type="radio" data-sum="<?php echo $total_sum; ?>" data-rate="<?php echo $row['shipping_rate']; ?>" class="form-check-input" id="shipping" name="optradio" value="<?php echo $row['shipping_id']; ?>"
                                        checked><?php echo $row['shipping_name']; ?>:<p> $<?php echo $row['shipping_rate']; ?></p>
                                </div>
                                <?php } ?>
                                <p>Shipping to <strong>Gujarat.</strong></p>
                                <a href="">Change address</a>
                            </td>
                        </tr>
                        <tr>
                            <th>Subtotal</th>
                            <td>$<p id="subtotal"></p></td>
                        </tr>
                    </table>
                    <a href="<?php echo base_url('index.php/Billing/checkout/'.$data['user_id']); ?>"><button class="btn btn_checkout">PROCEED TO CHECKOUT</button></a>
                </div>
        </div> -->
    </div>

    <?php include 'footer.php';?>
    <!-- <div id="footer"></div> -->

   
        <div class="whatsapp">
            <a href="https://api.whatsapp.com/send?phone=91----------" target="_blank">
                <h5>
                    <i class="fa fa-whatsapp fa-3x " aria-hidden="true"></i>
                </h5>
            </a>
        </div>
   
    <script src="<?php echo base_url(); ?>assets/home/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>js/jQuery/jquery.monte.js"></script>
    <script src="<?php echo base_url(); ?>assets/home/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/home/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/cart/js/cart.js"></script>
    <!-- <script src="<?php echo base_url(); ?>assets/home/js/script.js"></script> -->
</body>

</html>

<script type="text/javascript">
$(document).ready(function(){  
        //alert('hii');
    $(".quantity").change(function(){
        var quantity = $(".quantity").val();
        var id = $("#hidden").val();
        var price = $("#price").val();
        $.ajax({
                url:"<?php echo site_url('Product/update_quantity'); ?>",  
                method:"POST",  
                data:{quantity:quantity,id:id,price:price},  
                success:function(data){  
                    document.getElementById("total").innerHTML = data;
                    }  
				});	
    });

});
</script>