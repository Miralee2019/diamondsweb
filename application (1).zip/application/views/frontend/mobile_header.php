<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/head_foot/css/header.css">
        <script src="<?php echo base_url(); ?>assets/home/js/script.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        </head>
     <body>
    <div class="navigation_items">
        <div class="w3-sidebar w3-bar-block w3-animate-left" style="display:none;z-index:10000" id="mySidebar">
        <button onclick="w3_close()" class="w3-bar-item w3-button w3-large">Close &times;</button>
        <ul class="navbar-nav">
        <li class="nav-item">
            <a class="w3-bar-item w3-button" href="<?php echo base_url('index.php/Home'); ?>">Home</a>
        </li>
        <li class="nav-item">
            <a class="w3-bar-item w3-button" href="<?php echo base_url('index.php/Home/shop');?>">Shop</a>
        </li>
        <!-- <li class="nav-item" style="position: relative;">
            <a class="nav-link w3-bar-item w3-button dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Category</a>
                    <div class="dropdown-menu">
                    <?php foreach($subcategorie as $data=>$row){ ?>
                    <a class="w3-bar-item w3-button dropdown-item" href="#">Link 1</a>
                    <a class="w3-bar-item w3-button dropdown-item" href="#">Link 2</a>
                    <a class="w3-bar-item w3-button dropdown-item" href="#">Link 3</a>
                    <?php } ?>
                    </div>
        </li> -->
        <li class="nav-item" style="position: relative;"><a class="nav-link w3-bar-item w3-button dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Category</a>
            <ul class="child">
            <?php foreach($subcategorie as $data=>$row){ ?>
                <li class="parent"><a href="#"><?php echo $data; ?><span class="expand">»</span></a>
                    <ul class="child">
                    <?php foreach($row as $k=>$r){ ?>
                        <li><a href="<?php echo base_url('index.php/Home/subcategories/'.$k); ?>"><?php echo $r;?></a></li>
                    <?php } ?>
                    </ul>
                </li>
            <?php } ?>
            </ul>
        </li>
            <!-- <li class="nav-item" style="position: relative;">
            <a class="nav-link w3-bar-item w3-button dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Currency</a>
                <div class="dropdown-menu">
                <a class="dropdown-item w3-bar-item w3-button" href="#">United States (US) dollar</a>
                    <a class="dropdown-item w3-bar-item w3-button" href="#">Euro</a>
                    <a class="dropdown-item w3-bar-item w3-button" href="#">Pound sterling</a>
                    </div>
                </li> -->
            <li class="nav-item">
                <a class="nav-link w3-bar-item w3-button" href="<?php echo base_url('index.php/Home/aboutus'); ?>">About Us</a>
            </li>
                <li class="nav-item">
                <a class="nav-link w3-bar-item w3-button" href="<?php echo base_url('index.php/Home/contactus'); ?>">Contact Us</a>
                    </li>
                    <?php if($this->session->userdata('user_id') == null) { ?>
                    <li class="nav-item">
                        <a class="nav-link w3-bar-item w3-button" href="<?php echo base_url('index.php/Home/login'); ?>">Login</a>
                    </li>
                    <?php }else {?>
                        <li class="nav-item">
                        <a class="nav-link w3-bar-item w3-button" href="<?php echo base_url('index.php/Home/logout'); ?>">Logout</a>
                    </li>
                    <?php } ?>
            </ul>
    <!-- <ul id="menu">
            <li class="parent">
                <a href="<?php echo base_url('index.php/Home'); ?>">Home</a>
            </li>
            <li class="parent">
                <a href="<?php echo base_url('index.php/Home/categories'); ?>">Shop</a>
            </li>
            <li class="parent"><a href="#">Category</a>
                <ul class="child">
                <?php foreach($subcategorie as $data=>$row){ ?>
                    <li class="parent"><a href="#"><?php echo $data; ?><span class="expand">»</span></a>
                        <ul class="child">
                        <?php foreach($row as $r){ ?>
                            <li><a href="#"><?php echo $r;?></a></li>
                        <?php } ?>
                        </ul>
                    </li>
                <?php } ?>
                </ul>
            </li>
            <li class="parent"><a href="#">Currency</a>
                <ul class="child">			
                    <li><a href="#">United States (US) dollar</a></li>
                    <li><a href="#">Euro</a></li>
                    <li><a href="#">Pound sterling</a></li>
                </ul>
            </li>
            <li class="parent">
                <a href="<?php echo base_url('index.php/Home/aboutus'); ?>">About Us</a>
            </li>
            <li class="parent">
                <a href="<?php echo base_url('index.php/Home/contactus'); ?>">Contact Us</a>
            </li>
            <div style="clear:both;"></div>
        </ul> -->
    </div>
    <div class="w3-overlay w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" id="myOverlay"></div>
        <div class="row">
            <div class="humburger_menu col-sm-1 col-xs-1 text-left w3-white" style="padding: 0;">
                <button class="w3-button w3-white w3-xlarge" onclick="w3_open()">☰</button>
            </div>
            <div class="nav_bar col-sm-11 col-xs-1 text-center" style="padding: 0;">
                <div class="logo_image text-center" style="width: 110px; margin: 0 auto;">
                <img src="<?php echo base_url(); ?>assets/home/images/Maruti-Gems-Logo-02.jpg">
                </div>
            </div>
        </div>
        <div class="components_pro clearfix">
            <div class="md_input_area text-left clearfix">
                <input type="search" name="search" placeholder="Search for anything">
                <a href="#" class="md_search text-right">
                    <i style="font-size:20px" class="fa">&#xf002;</i>
                </a>
            </div>
            <div class="cart text-center">
                <a href="<?php if($this->session->userdata('user_id')) {
                                                echo base_url('index.php/Product/cart');
                                                 } else {
                                                    echo base_url('index.php/Home/login');
                                                } ?>">
                     <!-- <img src="<?php echo base_url(); ?>assets/head_foot/images/reusable-shopping-bag.svg" style="width: 100%; max-width: 28px;"> -->
                     <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:34px;"></i>
                    </a>
                <p class="cart_count"><a href=""><?php print_r($cart_data); ?></a></p>
            </div> 
            <div class="whishlist text-center">
                <a href="<?php if($this->session->userdata('user_id')) {
                                                echo base_url('index.php/Whishlist/whishlist');
                                                 } else {
                                                    echo base_url('index.php/Home/login');
                                                } ?>"><img src="<?php echo base_url(); ?>assets/head_foot/images/like.svg" style="width: 28px;"></a>
            </div>
        </div>
    </div>

<body>
</html>