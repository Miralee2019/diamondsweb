<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    function show_productvariation($p_id)
    {
        $this->db->select("*");
        $this->db->from('product');
        $this->db->where('product.p_id',$p_id);
        $this->db->join('variation', 'product.p_id = variation.p_id');
        $query = $this->db->get();
        $arr = $query->result_array();
		return $arr;
    }

    function review_insertdata($data)
    {
        $this->db->insert('review',$data);
    }

    function show_cartdata($user_id)
    {
        $this->db->select("*");
        $this->db->from('add_cart');
        $this->db->where('add_cart.user_id',$user_id);
        $this->db->join('product', 'product.p_id = add_cart.product_id');
        $query = $this->db->get();
        $arr = $query->result_array(); //print_r($arr);exit;
		return $arr;
    }

    function show_cartdatacount($user_id)
    {
        $this->db->select("*");
        $this->db->from('add_cart');
        $this->db->where('add_cart.user_id',$user_id);
        $this->db->join('product', 'product.p_id = add_cart.product_id');
        $query = $this->db->get();
        $arr = $query->num_rows(); //print_r($arr);exit;
		return $arr;
    }

    function delete_cartdata($cart_id='')
	{
		$this->db->where('cart_id',$cart_id);
		$this->db->delete('add_cart');
		//echo $this->db->last_query();
    }

    function show_shipping()
    {
        $this->db->select("*");
        $this->db->from('shipping');
        $query = $this->db->get();
        $arr = $query->result_array();
		return $arr;
    }

    function cart_insertdata($data)
    {
        $this->db->insert('add_cart',$data);
    }

    function updaterecords($id,$quantity,$total)
	{
		$query="UPDATE `add_cart` SET `quantity`='$quantity',`total_price`='$total' WHERE product_id=$id";
		$this->db->query($query);
        //print_r($arr);
	}
}