<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
    
    function show_subcategories()
    {
        //SELECT * from categories,sub_categories WHERE categories.id=sub_categories.c_id;
        $query=$this->db->query("SELECT * from categories,sub_categories WHERE categories.id=sub_categories.c_id");
        $arr = $query->result_array();
        return $arr;
    }
    
    function showdata_categories()
    {
        $qry=$this->db->get('categories');
        $arr=$qry->result_array();
        return $arr;
    }

    function showdata_product()
    {
        $qry=$this->db->select('*')->order_by('p_id',"desc")->limit(2)->get('product');
		$arr=$qry->result_array();
		return $arr;
    }

    function showdata_slider()
    {
        $qry=$this->db->get('slider');
		$arr=$qry->result_array();
		return $arr;
    }

    function categories_product($c_id)
    {
        $this->db->select("*");
        $this->db->from('categories');
        $this->db->where('categories.id',$c_id);
        $this->db->join('product', 'product.c_id = categories.id');
        $query = $this->db->get();
        $arr = $query->result_array();
		return $arr;
    }

    function subcategories_product($c_id)
    {
        $this->db->select("*");
        $this->db->from('sub_categories');
        $this->db->where('sub_categories.subc_id',$c_id);
        $this->db->join('product', 'product.subc_id = sub_categories.subc_id');
        $query = $this->db->get();
        $arr = $query->result_array();
		return $arr;
    }

    function getAllCountries()
    {
        $qry=$this->db->get('country');
		$arr=$qry->result_array();
		return $arr;
    }

    public function getStates() {
        $this->db->select(array('s.id as state_id', 's.country_id', 's.name as state_name'));
        $this->db->from('states as s');
        $this->db->where('s.country_id', $this->_countryID);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function getCities() {
        $this->db->select(array('i.id as city_id', 'i.name as city_name', 'i.state_id'));
        $this->db->from('cities as i');
        $this->db->where('i.state_id', $this->_stateID);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function contactus_insertdata($data)
    {
        $this->db->insert('contactus',$data);
    }

    public function show_all_product()
    {
        $this->db->select("*");
        $this->db->from('product');
        $this->db->join('categories', 'categories.id = product.c_id');
        $query = $this->db->get();
        $arr = $query->result_array();
		return $arr;
    }

    function show_saleproduct()
    {
        $query = $this->db->get('sale_product');
        $arr = $query->result_array();
        return $arr;
    }
    
    function searching_data($search)
    {
        $result = $this->db->like('pname', $search)
             ->get('product');

        return $result->result_array();
    }

    // function show_product($c_id)
    // {
    //     $this->db->where('c_id',$c_id);
    //     $qry=$this->db->get('product');
	// 	$arr=$qry->result_array();
	// 	return $arr;
    // }

    // function show_productvariation($p_id)
    // {
    //     $this->db->select("*");
    //     $this->db->from('product');
    //     $this->db->where('product.p_id',$p_id);
    //     $this->db->join('variation', 'product.p_id = variation.p_id');
    //     $query = $this->db->get();
    //     $arr = $query->result_array();
	// 	return $arr;
    // }

    // function registration_insertdata($data)
    // {
    //     $this->db->insert('registration',$data);
    // }

    // function check_user($emailid,$password)
	// {
	// 	$emailid=$this->input->post('email_id');	
	// 	$password=$this->input->post('password');
	// 	$this->db->where('email_id',$emailid);
	// 	$this->db->where('password',$password);
	// 	$qry=$this->db->get('registration');
	// 	//echo $this->db->last_query();
	// 	return $qry;
		
    // }

    // function showdata_user($user_id)
    // {
    //     $this->db->where('user_id',$user_id);
    //     $qry=$this->db->get('registration');
	// 	$arr=$qry->result_array();
	// 	return $arr;
    // }

    // function billing_insertdata($data)
    // {
    //     $this->db->insert('billing_detail',$data);
    // }

    // function shipping_insertdata($data)
    // {
    //     $this->db->insert('shipping_detail',$data);
    // }

    // function cart_insertdata($data)
    // {
    //     $this->db->insert('add_cart',$data);
    // }

}