
$(document).ready(function () {

  $(".product_description .reviewlink").click(function(){
      $(".reviewdesc_section").addClass("active");
      $(".product_description .productdesc_section").css("display", "none");
      //$(".product_description .reviewlink").addClass("text_effect");
     // $(".product_description .reviewlink").css({"border-bottom": "1px solid #001a6f", "color": "#8c8c8c"});
      // if($(".reviewdesc_section").hasClass("active")){
      //   $(".product_description .reviewlink").addClass("text_effect");
      // }else{
      //   $(".product_description .reviewlink").removeClass("text_effect");
      // }
  });
  $(".product_description .desclink").click(function(){
    $(".reviewdesc_section").removeClass("active");
    $(".product_description .productdesc_section").css("display", "block");
    //$(".product_description .desclink").css({"border-bottom": "1px solid #001a6f", "color": "#8c8c8c"});
});

  $(window).scroll(function () {
    var height = $(window).scrollTop();
    if (height > 100) {
      $('#back2Top').fadeIn();
    } else {
      $('#back2Top').fadeOut();
    }
  });
  $("#back2Top").click(function (event) {
    event.preventDefault();
    $("html, body").animate({ scrollTop: 0 }, "slow");
    return false;
  });
  $(document).scroll(function () {
    var $nav = $("#mainNavbar");
    $nav.toggleClass("scrolled", $(this).scrollTop() > $nav.height());
  });

});
