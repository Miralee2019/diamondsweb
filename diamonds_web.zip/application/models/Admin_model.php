<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    function insertdata_country($data)
    {
        $this->db->insert('country',$data);
    }

    function showdata_country()
    {
        $qry=$this->db->get('country');
		$arr=$qry->result_array();
		return $arr;
    }

    function insertdata_state($data)
    {
        $this->db->insert('state',$data);
    }

    function showdata_state()
    {
        $qry=$this->db->get('state');
		$arr=$qry->result_array();
		return $arr;
    }

    function insertdata_city($data)
    {
        $this->db->insert('city',$data);
    }

    function insertdata_categories($data)
    {
        $this->db->insert('categories',$data);
    }

    function showdata_categories()
    {
        $qry=$this->db->get('categories');
		$arr=$qry->result_array();
		return $arr;
    }

    function showdata_allproduct()
    {
        $qry=$this->db->get('product');
		$arr=$qry->result_array();
		return $arr;
    }

    function insertdata_subcategories($data)
    {
        $this->db->insert('sub_categories',$data);
    }

    function get_states()
    {
        return $this->db->get("state")->result_array();
    }

    function insertdata_product($data)
    {
        $this->db->insert('product',$data);
        return $this->db->insert_id();
    }

    function insertdata_productsale($data)
    {
        $this->db->insert('sale_product',$data);
    }

    function showdata_product($per_page,$start)
    {
        $this->db->limit($per_page,$start);
        return $this->db->get("product")->result_array();
    }

    function row_count()
	{
			$qry=$this->db->get('product');
			$arr=$qry->num_rows();
			return $arr;
    }
    
    function delete_productdata($p_id='')
	{
		$this->db->where('p_id',$p_id);
		$this->db->delete('product');
		//echo $this->db->last_query();
    }

    function createData($data) 
    {
        $query = $this->db->insert('variation', $data);
        return $query;
    }
    
    function update_productdata($p_id = '')
    {

            $p_name = $this->input->post('p_name');
            $categories = $this->input->post('categories');
            $subcategories = $this->input->post('subcategories');
            $price = $this->input->post('price');
            $image = $this->input->post('files');
            $weight = $this->input->post('weight');
            $shipping = $this->input->post('shipping[]');
            $shipping_data = implode(',',$shipping);
           
            $this->form_validation->set_rules('p_name','Product name','required');
            $this->form_validation->set_rules('categories','categories','required');
            $this->form_validation->set_rules('subcategories','subcategories','required');
            $this->form_validation->set_rules('price','price','required');
            $this->form_validation->set_rules('weight','weight','required');
            $this->form_validation->set_rules('shipping[]','Shipping','required');

			if($this->form_validation->run()==FALSE)
			{
				
			}
			else{
                if(!empty($_FILES['files']['name']) && count(array_filter($_FILES['files']['name'])) > 0)
                { 
                    $filesCount = count($_FILES['files']['name']); 
                    for($i = 0; $i < $filesCount; $i++)
                    { 
                        
                        $_FILES['file']['name']     = $_FILES['files']['name'][$i]; 
                        $_FILES['file']['type']     = $_FILES['files']['type'][$i]; 
                        $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i]; 
                        $_FILES['file']['error']     = $_FILES['files']['error'][$i]; 
                        $_FILES['file']['size']     = $_FILES['files']['size'][$i]; 
                        
                        $uploadPath = 'assets/images/'; 
                        $config['upload_path'] = $uploadPath; 
                        $config['max_size'] = '102400';
                        $config['allowed_types'] = 'gif|jpg|png|JPG|PNG|mov|mpeg|mp3|avi|mp4|gif|GIF'; 
                        $this->load->library('upload', $config); 
                        $this->upload->initialize($config); 
                        $this->upload->do_upload();
                        $dataInfo[] = $this->upload->data();
                        $img = $_FILES['files']['name'];
                        $image = implode(',',$img);
                        //print_r($image);exit;
						if($this->upload->do_upload('file'))
						{
                            $fileData = $this->upload->data(); 
                            $uploadData[$i]['file_name'] = $fileData['file_name']; 
							$arr=array(
                            'pname' => $p_name,
                            'c_id' => $categories,
                            'subc_id' => $subcategories,
                            'price' => $price,
                            'image' => $image,
                            'weight' => $weight,
                            'stock' => 0,
                            'shipping_id' => $shipping_data
                            );
                        //    $this->admin_model->insertdata_product($arr);
                        //    $id = $this->db->insert_id();
                        //    redirect('admin/Admin/addvariation/'.$id);
                           
                        }
						else
						{
							//$data['msg']="invalid email and password!!!!";
							$data['file_error']=$this->upload->display_error();
                        }
                    }
                }
            }
            
            $this->db->where('p_id',$p_id);
            $this->db->update('product',$arr);
            redirect('admin/Admin/updatevariation/'.$p_id);
    }

    function update_variation($p_id = '')
    {
        print_r($p_id);
        // $data  = array();
        // $variationTmp = $this->input->post('variation');
        // $variation_val = $this->input->post('variation_val');

        // foreach ($variationTmp as $key => $variation) {
        //     if($variation == "Color"){
        //         $data['d_color'] = $variation_val[$key];
        //     }elseif ($variation == "Cut") {
        //         $data['cut'] = $variation_val[$key];
        //     }elseif ($variation == "Shape") {
        //         $data['shape'] = $variation_val[$key];
        //     }elseif ($variation == "Treatment") {
        //         $data['treatment'] = $variation_val[$key];
        //     }elseif ($variation == "DiamondType") {
        //         $data['d_type'] = $variation_val[$key];
        //     }elseif ($variation == "DiamondSize") {
        //         $data['d_size'] = $variation_val[$key];
        //     }elseif ($variation == "RingSize") {
        //         $data['ring_size'] = $variation_val[$key];
        //     }elseif ($variation == "Luster") {
        //         $data['luster'] = $variation_val[$key];
        //     }elseif ($variation == "Clarity") {
        //         $data['clarity'] = $variation_val[$key];
        //     }elseif ($variation == "Color") {
        //         $data['d_color'] = $variation_val[$key];
        //     }elseif ($variation == "Certification") {
        //         $data['certification'] = $variation_val[$key];
        //     }elseif ($variation == "Gender") {
        //         $data['gender'] = $variation_val[$key];
        //     }elseif ($variation == "Weight") {
        //         $data['d_weight'] = $variation_val[$key];
        //     }elseif ($variation == "Metal") {
        //         $data['metal'] = $variation_val[$key];
        //     }elseif ($variation == "NOOfDiamond") {
        //         $data['no_of_diamond'] = $variation_val[$key];
        //     }elseif ($variation == "Bandwidth") {
        //         $data['band_width'] = $variation_val[$key];
        //     }elseif ($variation == "Ringweight") {
        //         $data['ring_weight'] = $variation_val[$key];
        //     }
        // }
    }
    
    function select_productrecord($p_id='')
    {
        
        $this->db->select("*");
        $this->db->from('product');
        $this->db->where('product.p_id',$p_id);
        $this->db->join('categories', 'categories.id = product.c_id');
        $this->db->join('sub_categories', 'sub_categories.c_id = categories.id');
        $query = $this->db->get();
        $arr = $query->row_array();
		return $arr;
    }

    function show_productvariation($p_id)
    {
        $this->db->select("*");
        $this->db->from('product');
        $this->db->where('product.p_id',$p_id);
        $this->db->join('variation', 'product.p_id = variation.p_id');
        $query = $this->db->get();
        $arr = $query->result_array();
		return $arr;
    }

    function showdata_saleproduct($per_page,$start)
    {
        $this->db->select("*");
        $this->db->from('sale_product');
        $this->db->join('product','sale_product.product_id = product.c_id');
        $query = $this->db->get();
        $arr['sale'] = $query->row_array();
        $arr['pro'] = explode(',',$arr['sale']['product_id']);
        
        foreach ($arr['pro'] as $k) {
            
        }
        //echo "<pre>";print_r($arr);exit;
		return $arr;
    }

    function insertdata_shipping($data)
    {
        $this->db->insert('shipping',$data);
    }

    function showdata_shipping()
    {
        $qry=$this->db->get('shipping');
		$arr=$qry->result_array();
		return $arr;
    }

    function delete_shippingdata($shipping_id='')
	{
		$this->db->where('shipping_id',$shipping_id);
		$this->db->delete('shipping');
		//echo $this->db->last_query();
    }

    function update_shippingdata($shipping_id = '')
    {

        $shipping_name = $this->input->post('shipping');
        $rate = $this->input->post('rate');
        
        $this->form_validation->set_rules('shipping','Shipping','required');
        $this->form_validation->set_rules('rate','Shipping rate','required');

        if($this->form_validation->run()==FALSE)
        {
            
        }
        else{
                        $arr=array(
                        'shipping_name'=>$shipping_name,
                        'shipping_rate' => $rate
                    );
            }
            
            $this->db->where('shipping_id',$shipping_id);
            $this->db->update('shipping',$arr);
            redirect('admin/Admin/view_shipping');
    }
    
    function show_data_shipping($shipping_id='')
    {
        
        $this->db->select('*');
        $this->db->from('shipping');
        $this->db->where('shipping_id',$shipping_id);
        $query = $this->db->get();
        $arr = $query->row_array();
		return $arr;
    }

    function insertdata_slider($data)
    {
        $this->db->insert('slider',$data);
    }
    
}