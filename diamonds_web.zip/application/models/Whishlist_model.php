<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Whishlist_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    function whishlist_insertdata($data)
    {
        $this->db->insert('whishlist',$data);
    }

    function show_whishlistdata($user_id)
    {
        $this->db->select("*");
        $this->db->from('whishlist');
        $this->db->where('whishlist.user_id',$user_id);
        $this->db->join('product', 'product.p_id = whishlist.product_id');
        $query = $this->db->get();
        $arr = $query->result_array(); //print_r($arr);exit;
		return $arr;
    }

    function delete_whishdata($whishlist_id='')
	{
		$this->db->where('whishlist_id',$whishlist_id);
		$this->db->delete('whishlist');
		//echo $this->db->last_query();
    }
}