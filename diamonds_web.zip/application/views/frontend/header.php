<html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/head_foot/css/header.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
    <body>
    <div class="row header_section">
        <div class="col-xl-2">
            <div class="logo">
                <img src="<?php echo base_url(); ?>assets/home/images/Maruti-Gems-Logo-02.jpg">
            </div>
        </div>
        <div class="col-xl-10">
            <div class="row nav_menu">
                <div class="col-xl-12">
                    <div class="input_area text-left">
                        <form method="post" action="<?php echo base_url('index.php/Home/header'); ?>">
                            <input type="search" class="search" name="search" placeholder="Search for anything">
                        </form>
                        <div class="input_icon text-right">
                            <a href="#" class="search">
                                <i style="font-size:24px" class="fa">&#xf002;</i>
                            </a>
                        </div>
                    </div>
                </div>
            </div><?php //print_r($categories); ?>
            <div class="row nav_menu">
                <div class="col-xl-10 subnav_menu">
                    <ul id="menu">
                        <li class="parent">
                            <a href="<?php echo base_url('index.php/Home'); ?>">Home</a>
                        </li>
                        <li class="parent">
                            <a href="<?php echo base_url('index.php/Home/shop'); ?>">Shop</a>
                        </li>
                        <li class="parent"><a href="#">Category</a>
                            <ul class="child">
                            <?php foreach($subcategorie as $data=>$row){ ?>
                                <li class="parent"><a href="#"><?php echo $data; ?><span class="expand">»</span></a>
                                    <ul class="child">
                                    <?php foreach($row as $k=>$r){ ?>
                                        <li><a href="<?php echo base_url('index.php/Home/subcategories/'.$k); ?>"><?php echo $r;?></a></li>
                                    <?php } ?>
                                    </ul>
                                </li>
                            <?php } ?>
                            </ul>
                        </li>
                        <!-- <li class="parent"><a href="#">Currency</a>
                            <ul class="child">			
                                <li><a href="#">United States (US) dollar</a></li>
                                <li><a href="#">Euro</a></li>
                                <li><a href="#">Pound sterling</a></li>
                            </ul>
                        </li> -->
                        <li class="parent">
                            <a href="<?php echo base_url('index.php/Home/aboutus'); ?>">About Us</a>
                        </li>
                        <li class="parent">
                            <a href="<?php echo base_url('index.php/Home/contactus'); ?>">Contact Us</a>
                        </li>
                        <?php if($this->session->userdata('user_id') == null) { ?>
                        <li class="parent">
                            <a href="<?php echo base_url('index.php/Home/login'); ?>">Login</a>
                        </li>
                        <?php }else {?>
                            <li class="parent">
                            <a href="<?php echo base_url('index.php/Home/logout'); ?>">Logout</a>
                        </li>
                        <?php } ?>
                        <div style="clear:both;"></div>
                    </ul>
                </div>
                <div class="pro_cart col-xl-2">
                    <a data-toggle="tooltip" title="Show Your Whishlist" class="whishlist" href="<?php echo base_url('index.php/Whishlist/whishlist'); ?>"><i class="fa fa-heart-o" style="font-size:24px; margin: 0 10px;color: #fff;"></i></a>
                    <a style="margin: 0 10px;" href="<?php echo base_url('index.php/Product/cart'); ?>"><img data-toggle="tooltip" title="Show Your Cart" src="<?php echo base_url(); ?>assets/head_foot/cart.png" style="width: 100%; max-width: 46px; position: relative;"></a>
                    <p class="cart_count clearfix"><a href=""><?php print_r($cart_data); ?></a></p>        

                    <!-- <a class="whishlist" href="<?php //echo base_url('index.php/Whishlist/add_whishlist/'.$data['p_id']); ?>"><i class="fa fa-heart-o" style="font-size:24px; margin: 0 10px;"></i></a>
                    <a style="margin: 0 10px;" href="<?php echo base_url('index.php/Product/cart'); ?>"><img src="<?php echo base_url(); ?>assets/head_foot/cart.png" style="width: 100%; max-width: 46px;"></a>
                    <p class="cart_count clearfix"><a href="">2</a></p> -->
                </div>
                <!-- <div class="pro_cart col-xl-1">
                    <a href="<?php echo base_url('index.php/Product/cart'); ?>"><img src="<?php echo base_url(); ?>assets/head_foot/cart.png" style="width: 100%; max-width: 46px;"></a>
                    <p class="cart_count clearfix"><a href="">2</a></p>
                </div> -->
            </div>
        </div>
    </div>
<body>
</html>

<script type="text/javascript">
// $(document).ready(function(){  
//     var search = $(".search").val();
//     alert(search);
// });
</script>