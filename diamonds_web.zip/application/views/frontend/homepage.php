<html>

<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/horizontalvertical.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/font-awesome.min.css"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/home/css/slick.theme.css" />
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <link href="<?php echo base_url(); ?>assets/home/css/material-components-web.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/home/css/w3.css">
   
    <style>
    .slider {
  width: 100%;
  height: 200px;
  position: relative;
  margin: auto;
  overflow-x: scroll;
  overflow-y: hidden;
}

.slider::-webkit-scrollbar {
  display: none;
}

.slider .slide {
  display: flex;
  position: absolute;
  left: 0;
  transition: 0.3s left ease-in-out;
}

.slider .item {
  margin-right: 10px;
}

.slider .item:last-child {
  margin-right: 0;
}

.ctrl {
  text-align: center;
  margin-top: 5px;
}

.ctrl-btn {
  padding: 20px 20px;
  min-width: 50px;
  background: #fff;
  border: none;
  font-weight: 600;
  text-align: center;
  cursor: pointer;
  outline: none;

  position: absolute;
  top: 50%;
  margin-top: -27.5px;
}

.ctrl-btn.pro-prev {
  left: 0;
}

.ctrl-btn.pro-next {
  right: 0;
}

</style>
</head>

<body>
        
    <?php //include 'header.php';?>
    <!-- <div id="header"></div> -->
    <?php //include 'mobile_header.php';?>
    <!-- <div id="mobile_header"></div> -->

<div class="banner">
    <div id="indicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#indicators" data-slide-to="0" class="active"></li>
            <li data-target="#indicators" data-slide-to="1"></li>
            <li data-target="#indicators" data-slide-to="2"></li>
        </ol>
        <div class="row carousel-inner" role="listbox">
            <?php foreach($slider as $row){ ?>
            <div class="col-xl-12 col-md-12 col-sm-12 carousel-item active" data-mdb-interval="100000"
                style="padding: 0; background-image: url('<?php echo base_url('assets/images/'.$row['image']); ?>')">
                <div class="carousel-caption d-sm-block d-md-block">
                    <h1 class="ml3"><?php echo $row['slider_text']; ?></h1>
                </div>
            </div>
            <?php } ?>
            <!-- <div class="col-xl-12 col-md-12 col-sm-12 carousel-item "
                style="padding: 0; background-image: url('<?php echo base_url(); ?>assets/home/images/slider3.jpg')">
                <div class="carousel-caption d-sm-block d-md-block">
                    <h1 class="ml2">Sunny mornings</h1>
                </div>
            </div>
            <div class="col-xl-12 col-md-12 col-sm-12 carousel-item"
                style="padding: 0; background-image: url('<?php echo base_url(); ?>assets/home/images/slider2.jpg    ')">
                <div class="carousel-caption d-sm-block d-md-block">
                    <h1 class="ml12">A new production</h1>
                </div>
            </div> -->
        </div> <a class="carousel-control-prev" href="#indicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#indicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a>
    </div>
</div>
   
    <div class="row product_collection">
        <div class="container"> <?php foreach($categories as $data){ //print_r($data);?>
            <div class="col-xl-4 col-md-4 col-sm-12 product_container">
                <div class="back_image">
                    <a href="<?php echo base_url('index.php/Home/categories/'.$data['id']); ?>">
                        <div class="img">
                            <img src="<?php echo base_url('assets/images/'.$data['images']); ?>">
                        </div>
                        <div class="product_content">
                            <h6><?php echo $data['categories_name']; ?></h6>
                            <!-- <p>product content</p> -->
                        </div>
                    </a>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
    <div class="container">
        <div class="trending_products text-center">
            <div class="text_border">
                <h2 class="before_border">Trending <span>Products</span></h2>
            </div><?php //echo '<pre>'; print_r($product); ?>
            <div class="row trending_collection">
                <?php foreach($product as $data){  //print_r($data['image']);
                    $img = explode(',',$data['image']); ?>
                <div class="col-xl-4 col-md-4 col-sm-12 product_overlay">
                    <div class="img shadow mb-5 bg-white rounded mdc-card mdc-card--outlined">
                        <a href="<?php echo base_url('index.php/Product/product/'.$data['p_id']); ?>">
                            <img class="top" src="<?php echo base_url('assets/images/'.$img['1']); ?>">
                            <img class="w3-animate-top content_overlay" src="<?php echo base_url('assets/images/'.$img['0']); ?>">
                            <div class="pro_icon_content">
                                <div class="content_overlay">
                                    <!-- <a class="search_icon" data-p_id=<?php echo $data['p_id'];?>>
                                        <i class="fa fa-search" style="font-size:24px"></i>
                                    </a> -->
                                    <a href="<?php echo base_url('index.php/Whishlist/add_whishlist/'.$data['p_id']); ?>" class="whishlist">
                                        <i class="fa fa-heart-o" style="font-size:24px;"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="product_content text-left">
                                <div class="pro_grid">
                                    <div class="pro_info">
                                        <a href="<?php echo base_url('index.php/Product/product/'.$data['p_id']); ?>"><?php echo $data['pname']; ?></a>
                                    </div>
                                    <div class="price_cart clearfix">
                                        <div class="price_box">
                                            <p>$<?php echo $data['price']; ?></p>
                                        </div>
                                        <div class="btn_info">
                                            <a href="<?php if($this->session->userdata('user_id')) {
                                                echo base_url('index.php/Product/product/'.$data['p_id']);
                                                 } else {
                                                    echo base_url('index.php/Home/login');
                                                } ?>"><i style="font-size:36px" class="fa">&#xf07a;</i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>

    <div class="row product_essential_content">
    <?php foreach($product as $data){  //print_r($data['image']);
                    $img = explode(',',$data['image']); ?>
        <div class="col-xl-6 col-md-12 col-sm-12 col-xs-12 product_essential_section">
            <div class="pro_img_content">
                <a class="pro_image" href="<?php echo base_url('index.php/Product/product/'.$data['p_id']); ?>">
                    <img src="<?php echo base_url('assets/images/'.$img['1']); ?>">
                </a>
            </div>
            <div class="product_essential">
                <a href="<?php echo base_url('index.php/Product/product'); ?>">
                    <p class="pro_one_desc">Product Essentials</p>
                    <p class="pro_two_desc"><?php echo $data['pname']; ?></p>
                    <p class="pro_three_desc">A natural quality</p>
                    <a href="<?php echo base_url('index.php/Product/product/'.$data['p_id']); ?>"><button class="btn">BUY NOW</button></a>
                </a>
            </div>
        </div>  
        <?php } ?>
    </div>

    <div class="slider" id="slider">
        <div class="slide" id="slide">
            <div class=" item thumb-wrapper" style="width: 200px">
                <div class="onsale_img shadow mb-5 bg-white rounded mdc-card mdc-card--outlined">
                    <a href="">
                        <img class="onsale_top" src="<?php echo base_url(); ?>assets/home/images/download2.jpg" class="img-fluid" alt="">
                        <img class="w3-animate-zoom  onsale_content_overlay" src="<?php echo base_url(); ?>assets/home/images/darkbg3.jpg">
                        <div class="pro_icon_content">
                            <div class="onsale_content_overlay">
                                <a class="search_icon">
                                    <i class="fa fa-search" style="font-size:24px"></i>
                                </a>
                                <a class="whishlist">
                                    <i class="fa fa-heart-o" style="font-size:24px;"></i>
                                </a>
                            </div>
                        </div>
                    </a>
                    <div class="product_content text-left">
                        <div class="pro_grid">
                            <div class="pro_info">
                                <a href="<?php echo base_url('index.php/Product/product'); ?>">1.28 CT Salt and Pepper Round Brilliant Cut Natural Polished
                                </a>
                            </div>
                            <div class="price_cart clearfix">
                                <div class="price_box clearfix">
                                    <p>$544.00</p>
                                </div>
                                <div class="btn_info">
                                    <a href="<?php if($this->session->userdata('user_id')) {
                            echo base_url('index.php/Product/product/'.$data['p_id']);
                                } else {
                                echo base_url('index.php/Home/login');
                            } ?>"><i style="font-size:32px" class="fa">&#xf07a;</i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" item thumb-wrapper" style="width: 200px">
                <div class="onsale_img shadow mb-5 bg-white rounded mdc-card mdc-card--outlined">
                    <a href="">
                        <img class="onsale_top" src="<?php echo base_url(); ?>assets/home/images/download2.jpg" class="img-fluid" alt="">
                        <img class="w3-animate-zoom  onsale_content_overlay" src="<?php echo base_url(); ?>assets/home/images/darkbg3.jpg">
                        <div class="pro_icon_content">
                            <div class="onsale_content_overlay">
                                <a class="search_icon">
                                    <i class="fa fa-search" style="font-size:24px"></i>
                                </a>
                                <a class="whishlist">
                                    <i class="fa fa-heart-o" style="font-size:24px;"></i>
                                </a>
                            </div>
                        </div>
                    </a>
                    <div class="product_content text-left">
                        <div class="pro_grid">
                            <div class="pro_info">
                                <a href="<?php echo base_url('index.php/Product/product'); ?>">1.28 CT Salt and Pepper Round Brilliant Cut Natural Polished
                                </a>
                            </div>
                            <div class="price_cart clearfix">
                                <div class="price_box clearfix">
                                    <p>$544.00</p>
                                </div>
                                <div class="btn_info">
                                    <a href="<?php if($this->session->userdata('user_id')) {
                            echo base_url('index.php/Product/product/'.$data['p_id']);
                                } else {
                                echo base_url('index.php/Home/login');
                            } ?>"><i style="font-size:32px" class="fa">&#xf07a;</i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" item thumb-wrapper" style="width: 200px">
                <div class="onsale_img shadow mb-5 bg-white rounded mdc-card mdc-card--outlined">
                    <a href="">
                        <img class="onsale_top" src="<?php echo base_url(); ?>assets/home/images/download2.jpg" class="img-fluid" alt="">
                        <img class="w3-animate-zoom  onsale_content_overlay" src="<?php echo base_url(); ?>assets/home/images/darkbg3.jpg">
                        <div class="pro_icon_content">
                            <div class="onsale_content_overlay">
                                <a class="search_icon">
                                    <i class="fa fa-search" style="font-size:24px"></i>
                                </a>
                                <a class="whishlist">
                                    <i class="fa fa-heart-o" style="font-size:24px;"></i>
                                </a>
                            </div>
                        </div>
                    </a>
                    <div class="product_content text-left">
                        <div class="pro_grid">
                            <div class="pro_info">
                                <a href="<?php echo base_url('index.php/Product/product'); ?>">1.28 CT Salt and Pepper Round Brilliant Cut Natural Polished
                                </a>
                            </div>
                            <div class="price_cart clearfix">
                                <div class="price_box clearfix">
                                    <p>$544.00</p>
                                </div>
                                <div class="btn_info">
                                    <a href="<?php if($this->session->userdata('user_id')) {
                            echo base_url('index.php/Product/product/'.$data['p_id']);
                                } else {
                                echo base_url('index.php/Home/login');
                            } ?>"><i style="font-size:32px" class="fa">&#xf07a;</i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" item thumb-wrapper" style="width: 200px">
                <div class="onsale_img shadow mb-5 bg-white rounded mdc-card mdc-card--outlined">
                    <a href="">
                        <img class="onsale_top" src="<?php echo base_url(); ?>assets/home/images/download2.jpg" class="img-fluid" alt="">
                        <img class="w3-animate-zoom  onsale_content_overlay" src="<?php echo base_url(); ?>assets/home/images/darkbg3.jpg">
                        <div class="pro_icon_content">
                            <div class="onsale_content_overlay">
                                <a class="search_icon">
                                    <i class="fa fa-search" style="font-size:24px"></i>
                                </a>
                                <a class="whishlist">
                                    <i class="fa fa-heart-o" style="font-size:24px;"></i>
                                </a>
                            </div>
                        </div>
                    </a>
                    <div class="product_content text-left">
                        <div class="pro_grid">
                            <div class="pro_info">
                                <a href="<?php echo base_url('index.php/Product/product'); ?>">1.28 CT Salt and Pepper Round Brilliant Cut Natural Polished
                                </a>
                            </div>
                            <div class="price_cart clearfix">
                                <div class="price_box clearfix">
                                    <p>$544.00</p>
                                </div>
                                <div class="btn_info">
                                    <a href="<?php if($this->session->userdata('user_id')) {
                            echo base_url('index.php/Product/product/'.$data['p_id']);
                                } else {
                                echo base_url('index.php/Home/login');
                            } ?>"><i style="font-size:32px" class="fa">&#xf07a;</i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" item thumb-wrapper" style="width: 200px">
                <div class="onsale_img shadow mb-5 bg-white rounded mdc-card mdc-card--outlined">
                    <a href="">
                        <img class="onsale_top" src="<?php echo base_url(); ?>assets/home/images/download2.jpg" class="img-fluid" alt="">
                        <img class="w3-animate-zoom  onsale_content_overlay" src="<?php echo base_url(); ?>assets/home/images/darkbg3.jpg">
                        <div class="pro_icon_content">
                            <div class="onsale_content_overlay">
                                <a class="search_icon">
                                    <i class="fa fa-search" style="font-size:24px"></i>
                                </a>
                                <a class="whishlist">
                                    <i class="fa fa-heart-o" style="font-size:24px;"></i>
                                </a>
                            </div>
                        </div>
                    </a>
                    <div class="product_content text-left">
                        <div class="pro_grid">
                            <div class="pro_info">
                                <a href="<?php echo base_url('index.php/Product/product'); ?>">1.28 CT Salt and Pepper Round Brilliant Cut Natural Polished
                                </a>
                            </div>
                            <div class="price_cart clearfix">
                                <div class="price_box clearfix">
                                    <p>$544.00</p>
                                </div>
                                <div class="btn_info">
                                    <a href="<?php if($this->session->userdata('user_id')) {
                            echo base_url('index.php/Product/product/'.$data['p_id']);
                                } else {
                                echo base_url('index.php/Home/login');
                            } ?>"><i style="font-size:32px" class="fa">&#xf07a;</i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <button class="ctrl-btn pro-prev">Prev</button>
        <button class="ctrl-btn pro-next">Next</button>
      </div>
    
    <!-- <div class="pro_slider">
        <div class="row">
            <div class="col-md-12">
                <div class="text_underborder">
                    <span class="icon">
                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    </span>
                    <h2 class="border_contant">ON<span class="icon_content"> SALE</span></h2>
                </div>
                <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="0">
                    
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="row">
                                <div class="thumb-wrapper" style="width: 200px">
                                    <div class="onsale_img shadow mb-5 bg-white rounded mdc-card mdc-card--outlined">
                                        <a href="">
                                            <img class="onsale_top" src="<?php echo base_url(); ?>assets/home/images/download2.jpg" class="img-fluid" alt="">
                                            <img class="w3-animate-zoom  onsale_content_overlay" src="<?php echo base_url(); ?>assets/home/images/darkbg3.jpg">
                                            <div class="pro_icon_content">
                                                <div class="onsale_content_overlay">
                                                    <a class="search_icon">
                                                        <i class="fa fa-search" style="font-size:24px"></i>
                                                    </a>
                                                    <a class="whishlist">
                                                        <i class="fa fa-heart-o" style="font-size:24px;"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </a>
                                        <div class="product_content text-left">
                                            <div class="pro_grid">
                                                <div class="pro_info">
                                                    <a href="<?php echo base_url('index.php/Product/product'); ?>">1.28 CT Salt and Pepper Round Brilliant Cut Natural Polished
                                                    </a>
                                                </div>
                                                <div class="price_cart clearfix">
                                                    <div class="price_box clearfix">
                                                        <p>$544.00</p>
                                                    </div>
                                                    <div class="btn_info">
                                                        <a href="<?php if($this->session->userdata('user_id')) {
                                                echo base_url('index.php/Product/product/'.$data['p_id']);
                                                 } else {
                                                    echo base_url('index.php/Home/login');
                                                } ?>"><i style="font-size:32px" class="fa">&#xf07a;</i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="thumb-wrapper"  style="width: 200px">
                                    <div class="onsale_img shadow mb-5 bg-white rounded mdc-card mdc-card--outlined">
                                        <a href="<?php echo base_url('index.php/Product/product'); ?>">
                                            <img class="onsale_top" src="<?php echo base_url(); ?>assets/home/images/diamond3.jpg">
                                            <img class="w3-animate-zoom onsale_content_overlay" src="<?php echo base_url(); ?>assets/home/images/darkbg3.jpg">
                                            <div class="pro_icon_content">
                                                <div class="onsale_content_overlay">
                                                    <i class="fa fa-search" style="font-size:24px"></i>
                                                    <i class="fa fa-heart-o" style="font-size:24px;"></i>
                                                </div>
                                            </div>
                                            <div class="product_content text-left">
                                                <div class="pro_grid">
                                                    <div class="pro_info">
                                                        <a href="<?php echo base_url('index.php/Product/product'); ?>">1.28 CT Salt and Pepper Round Brilliant Cut Natural
                                                            Polished</a>
                                                    </div>
                                                    <div class="price_cart clearfix">
                                                        <div class="price_box clearfix">
                                                            <p>$544.00</p>
                                                        </div>
                                                        <div class="btn_info">
                                                            <a href="<?php echo base_url('index.php/Home/cart'); ?>"><i style="font-size:36px" class="fa">&#xf07a;</i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <a class="carousel-control-next" href="#myCarousel" data-slide="next">
                        <i class="fa fa-angle-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </div> -->
    </div>
    <div class="partners_slider">
        <div class="container slider_section">
            <div class="slider_items">
                <div class="items w3-animate-zoom">
                    <div><img src="<?php echo base_url(); ?>assets/home/images/Visa.png"></div>
                    <div><img src="<?php echo base_url(); ?>assets/home/images/Brinks-Logo.png"></div>
                    <div><img src="<?php echo base_url(); ?>assets/home/images/DHL.png"></div>
                    <div><img src="<?php echo base_url(); ?>assets/home/images/fedex.png"></div>
                    <div><img src="<?php echo base_url(); ?>assets/home/images/india-post.png"></div>
                    <div><img src="<?php echo base_url(); ?>assets/home/images/Mastercard.png"></div>
                    <div><img src="<?php echo base_url(); ?>assets/home/images/paypal.png"></div>
                    <div><img src="<?php echo base_url(); ?>assets/home/images/ups.png"></div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer.php';?>
    <!-- <div id="footer"></div> -->

    <div class="modal-popup sizechart-popup">
        <div class="modal-wrap">
            <!-- <div class="modal-body">
                <div class="modal-content">
                    <div class="icon_close">
                        <i style="font-size:24px" class="fa">&#xf00d;</i>
                    </div>
                    <div class="row slider_popup">
                        <div class="slider_content col-xl-12" style="margin: 0 auto; padding: 0; width: unset;">
                            <section>
                                <div class="rt-container">
                                    <div class="col-rt-12 slider_horizon clearfix" style="margin: 0 28px;">
                                        <div class="horVerSlider" data-desktop="800" data-tabportrait="600"
                                            data-tablandscape="600" data-mobilelarge="375" data-mobilelandscape="500"
                                            data-mobileportrait="375">
                                            <div class="close"></div>
                                            <div class="vertical-wrapper">
                                                <div id="vertical-slider">
                                                    <ul>
                                                        <li data-image="assets/product/images/1.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/1.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/2.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/2.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/3.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/3.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/4.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/4.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/5.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/5.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/6.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/6.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/7.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/7.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/8.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/8.jpg">
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="horizon-wrapper ">
                                                <div class="horizone-nav">
                                                    <div class="prev" style="display: none;">
                                                        <img src="<?php echo base_url(); ?>assets/product/images/leftarrow.svg" />
                                                    </div>
                                                    <div class="next" style="display: block;">
                                                        <img src="<?php echo base_url(); ?>assets/product/images/rightarrow.svg" />
                                                    </div>
                                                </div>
                                                <div id="horizon-slider" class="zoomin zoomenable zoomed">
                                                    <ul style="left: 0px; top: 0px;">
                                                        <li data-image="assets/product/images/1.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/1.jpg" class="zoom"
                                                                data-magnify-src="assets/product/images/1.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/2.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/2.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/3.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/3.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/4.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/4.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/5.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/5.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/6.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/6.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/7.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/7.jpg">
                                                        </li>
                                                        <li data-image="assets/product/images/8.jpg"
                                                            class="ui-draggable ui-draggable-handle ui-draggable-disabled">
                                                            <img src="<?php echo base_url(); ?>assets/product/images/8.jpg">
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="dots">
                                                    <div class="dotwrap"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                        <div class="col-xl-12 col-md-12 col-sm-12 popup_desc">
                            <div class="popup_pro_desc">
                                <div class="title">
                                    <h5>1.08 CT Salt and Pepper Kite Shape Natural Loose Diamond For Engagement Ring
                                    </h5>
                                </div>
                                <div class="price">
                                    <p>$485.00 $373.00</p>
                                </div>
                                <div class="all_feature">
                                    <a href="">See all features</a>
                                </div>
                                <div class="stock_count">
                                    <p><span>8</span>in stock</p>
                                </div>
                                <div class="product_cart_btn">
                                    <button class="btn btn_cart"><a href="<?php echo base_url('index.php/Home/cart'); ?>">+ Add To Cart</a></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
    
    <div class="whatsapp">
        <a href="https://api.whatsapp.com/send?phone=91----------" target="_blank">
            <h5>
                <i class="fa fa-whatsapp fa-3x " aria-hidden="true"></i>
            </h5>
        </a>
    </div>
    
    <!-- <script src="<?php echo base_url(); ?>js/jQuery/jquery.monte.js"></script> -->
    <script src="<?php echo base_url(); ?>assets/home/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/home/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/home/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/home/js/horizontalvertical.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/home/js/slick.min.js"></script>
    <script src="https://unpkg.com/material-components-web@latest/dist/material-components-web.min.js"></script>
    <script>
    "use strict";

productScroll();

function productScroll() {
  let slider = document.getElementById("slider");
  let next = document.getElementsByClassName("pro-next");
  let prev = document.getElementsByClassName("pro-prev");
  let slide = document.getElementById("slide");
  let item = document.getElementById("slide");

  for (let i = 0; i < next.length; i++) {
    //refer elements by class name

    let position = 0; //slider postion

    prev[i].addEventListener("click", function() {
      //click previos button
      if (position > 0) {
        //avoid slide left beyond the first item
        position -= 1;
        translateX(position); //translate items
      }
    });

    next[i].addEventListener("click", function() {
      if (position >= 0 && position < hiddenItems()) {
        //avoid slide right beyond the last item
        position += 1;
        translateX(position); //translate items
      }
    });
  }

  function hiddenItems() {
    //get hidden items
    let items = getCount(item, false);
    let visibleItems = slider.offsetWidth / 210;
    return items - Math.ceil(visibleItems);
  }
}

function translateX(position) {
  //translate items
  slide.style.left = position * -210 + "px";
}

function getCount(parent, getChildrensChildren) {
  //count no of items
  let relevantChildren = 0;
  let children = parent.childNodes.length;
  for (let i = 0; i < children; i++) {
    if (parent.childNodes[i].nodeType != 3) {
      if (getChildrensChildren)
        relevantChildren += getCount(parent.childNodes[i], true);
      relevantChildren++;
    }
  }
  return relevantChildren;
}

</script>
</body>
<!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/home/js/script.js"></script> -->

</html>

<script type="text/javascript">
    $(".search_icon").click(function(e){
            e.preventDefault();
            var p_id = $(this).data('p_id');
            var html = "";
            //alert(p_id);
            $.ajax({ 
                        type:'POST',
                        url: "<?php echo base_url(); ?>" + "index.php/Product/popup_product/" + p_id,
                        data:{p_id:p_id},
                        success:function(data)
                        {
                            //alert('hii');
                            //alert(data);
                            html+= '<div class="modal-body">'+
                                        '<div class="modal-content">'+
                                            '<div class="icon_close">'+
                                                '<i style="font-size:24px" class="fa">&#xf00d;</i>'+
                                            '</div>'+
                                            '<div class="row slider_popup">'+
                                                '<div class="slider_content col-xl-12" style="margin: 0 auto; padding: 0; width: unset;">'+
                                                    '<section>'+
                                                        '<div class="rt-container">'+
                                                            '<div class="col-rt-12 slider_horizon clearfix" style="margin: 0 28px;">'+
                                                                '<div class="horVerSlider" data-desktop="800" data-tabportrait="600" data-tablandscape="600" data-mobilelarge="375" data-mobilelandscape="500" data-mobileportrait="375">'+
                                                                    '<div class="close"></div>'+
                                                                    '<div class="vertical-wrapper">'+
                                                                        '<div id="vertical-slider">'+
                                                                            '<ul>'+
                                                                                '<li data-image="assets/product/images/1.jpg" class="ui-draggable ui-draggable-handle ui-draggable-disabled">'+
                                                                                    '<img src="<?php echo base_url(); ?>assets/product/images/1.jpg">'+
                                                                                '</li>'+
                                                                            '</ul>'+
                                                                        '</div>'+
                                                                    '</div>'+
                                                                    '<div class="horizon-wrapper ">'+
                                                                        '<div class="horizone-nav">'+
                                                                            '<div class="prev" style="display: none;">'+
                                                                                '<img src="<?php echo base_url(); ?>assets/product/images/leftarrow.svg" />'+
                                                                            '</div>'+
                                                                            '<div class="next" style="display: block;">'+
                                                                                '<img src="<?php echo base_url(); ?>assets/product/images/rightarrow.svg" />'+
                                                                            '</div>'+
                                                                        '</div>'+
                                                                        '<div id="horizon-slider" class="zoomin zoomenable zoomed">'+
                                                                            '<ul style="left: 0px; top: 0px;">'+
                                                                                '<li data-image="assets/product/images/1.jpg" class="ui-draggable ui-draggable-handle ui-draggable-disabled">'+
                                                                                    '<img src="<?php echo base_url(); ?>assets/product/images/1.jpg" class="zoom" data-magnify-src="assets/product/images/1.jpg">'+
                                                                                '</li>'+
                                                                            '</ul>'+
                                                                        '</div>'+
                                                                        '<div class="dots">'+
                                                                            '<div class="dotwrap"></div>'+
                                                                        '</div>'+
                                                                    '</div>'+
                                                                '</div>'+
                                                            '</div>'+
                                                        '</div>'+
                                                    '</section>'+
                                                '</div>'+
                                                '<div class="col-xl-12 col-md-12 col-sm-12 popup_desc">'+
                                                    '<div class="popup_pro_desc">'+
                                                        '<div class="title">'+
                                                            '<h5>1.08 CT Salt and Pepper Kite Shape Natural Loose Diamond For Engagement Ring</h5>'+
                                                        '</div>'+
                                                        '<div class="price">'+
                                                            '<p>$485.00 $373.00</p>'+
                                                        '</div>'+
                                                        '<div class="all_feature">'+
                                                            '<a href="">See all features</a>'+
                                                        '</div>'+
                                                        '<div class="stock_count">'+
                                                            '<p><span>8</span>in stock</p>'+
                                                        '</div>'+
                                                        '<div class="product_cart_btn">'+
                                                            '<button class="btn btn_cart"><a href="<?php echo base_url('index.php/Home/cart'); ?>">+ Add To Cart</a></button>'+
                                                        '</div>'+
                                                    '</div>'+
                                                '</div>'+
                                            '</div>'+
                                        '</div>'+
                                    '</div>';
                        }
                        $(".modal-wrap").html(html); 
                    });	
        $(".modal-popup").addClass("modal-visible");
        });
</script>