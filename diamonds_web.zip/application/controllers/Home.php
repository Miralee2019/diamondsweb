<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->model('Home_model');
        $this->load->model('Product_model');
        $this->load->library('form_validation');
        $this->load->library('session');
    }

    public function index()
    {
        $user_id = $this->session->userdata('user_id');
        $subcategories = $this->Home_model->show_subcategories(); //echo '<pre>'; print_r($subcategories);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               //echo '<pre>'; print_r($subcat);
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories; //echo '<pre>'; print_r($arr['subcategorie']);
        $arr['product']=$this->Home_model->showdata_product();
        $arr['slider'] = $this->Home_model->showdata_slider();
        $arr['cart_data'] = $this->Product_model->show_cartdatacount($user_id);
        $arr['saleproduct']=$this->Home_model->show_saleproduct();
        $this->load->view('frontend/header',$arr);
        $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/homepage',$arr);
    }

    public function header()
    {
        $search = $this->input->post('search');
        $data['searching'] = $this->Home_model->searching_data($search); echo '<pre>'; print_r($data);
    }

    public function categories($categories_id)
    {
        //print_r($categories_id);
        $user_id = $this->session->userdata('user_id');
        $subcategories = $this->Home_model->show_subcategories();
        //echo '<pre>';print_r($arr['sub']);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories;
        $arr['cart_data'] = $this->Product_model->show_cartdatacount($user_id);
        $arr['category']=$this->Home_model->categories_product($categories_id); //print_r($arr);
        $this->load->view('frontend/header',$arr);
        $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/categories',$arr);
    }

    public function subcategories($subcategories_id)
    {
        $user_id = $this->session->userdata('user_id');
        //print_r($categories_id);
        $subcategories = $this->Home_model->show_subcategories();
        //echo '<pre>';print_r($arr['sub']);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories;
        $arr['cart_data'] = $this->Product_model->show_cartdatacount($user_id);
        $arr['category']=$this->Home_model->subcategories_product($subcategories_id); //print_r($arr);
        $this->load->view('frontend/header',$arr);
        $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/subcategories',$arr);
    }

    public function contactus()
    {
        $user_id = $this->session->userdata('user_id');
        $subcategories = $this->Home_model->show_subcategories();
        //echo '<pre>';print_r($arr['sub']);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories;
        $arr['cart_data'] = $this->Product_model->show_cartdatacount($user_id);
        $this->load->view('frontend/header',$arr);
        $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/contactus');
    }

    public function add_contactusdata()
    {
        $user_id = $this->session->userdata('user_id'); //print_r($user_id);
        $data=array();

            $fname = $this->input->post('fname');
            $lname = $this->input->post('lname');
            $email = $this->input->post('email');
            $phone = $this->input->post('phone');
            $message = $this->input->post('message');

            $this->form_validation->set_rules('fname','First name','required');
            $this->form_validation->set_rules('lname','Last name','required');
            $this->form_validation->set_rules('email','Email','required');
            $this->form_validation->set_rules('phone','Phone no','required');
            $this->form_validation->set_rules('message','Message','required');

            if($this->form_validation->run()==FALSE)    
            { 
                $res = array(
                    'status' => "fail",
                    'message' => "registration fail"
                );

            }else{
                $data = array(
                    'f_name' => $fname,
                    'l_name' => $lname,
                    'email' => $email,
                    'phone_no' => $phone,
                    'message' => $message
                );
                //print_r($data); exit;
                $this->Home_model->contactus_insertdata($data);
                $res = array(
                    'status' => "success",
                    'message' => "Add to cart Successfully"
                );
                redirect('Home/contactus');
            }
    }

    public function aboutus()
    {
        $user_id = $this->session->userdata('user_id');
        $subcategories = $this->Home_model->show_subcategories();
        //echo '<pre>';print_r($arr['sub']);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories;
        $arr['cart_data'] = $this->Product_model->show_cartdatacount($user_id);
        $this->load->view('frontend/header',$arr);
        $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/aboutus');
    }

    public function login()
    {
        $subcategories = $this->Home_model->show_subcategories();
        //echo '<pre>';print_r($arr['sub']);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories;
        $arr['Countries'] = $this->Home_model->getAllCountries();
        $arr['cart_data'] = $this->Product_model->show_cartdatacount($user_id);
        $this->load->view('frontend/header',$arr);
        $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/login',$arr);
    }

    public function getstates() {
        $id = $this->input->post('id');
        $this->db->where('id',$id);
        $data['state']=$this->db->get('state')->result_array();
        $this->load->view('frontend/get_state',$data);
    }
 
    function getcities() {
        $id = $this->input->post('id');
        $this->db->where('id',$id);
        $data['city']=$this->db->get('city')->result_array();
        $this->load->view('frontend/get_city',$data);
    }

    public function shop()
    {
        $user_id = $this->session->userdata('user_id');
        $subcategories = $this->Home_model->show_subcategories();
        //echo '<pre>';print_r($arr['sub']);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories;
        $arr['cart_data'] = $this->Product_model->show_cartdatacount($user_id);
        $arr['all_product'] = $this->Home_model->show_all_product(); //echo '<pre>';  print_r($arr['all_product']); exit();
        $this->load->view('frontend/header',$arr);
        $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/shop',$arr);
    }

    public function logout()
    {
        session_destroy();
        redirect('Home');
    }
    
}