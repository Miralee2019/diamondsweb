<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

    function __construct() {
        parent::__construct();

        $this->load->database();
        $this->load->model('Product_model');
        $this->load->model('Home_model');
        $this->load->library('form_validation');
        $this->load->library('session');
    }

    public function popup_product($p_id = null)
    {
        //echo 'hii';
        //print_r($p_id);
        $arr['productvariation'] = $this->Product_model->show_productvariation($p_id);
        echo json_encode($arr);
    }

    public function product($p_id = null)
    { //echo 'hi';
        $subcategories = $this->Home_model->show_subcategories();
        //echo '<pre>';print_r($arr['sub']);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories;
        $arr['user_id'] = $this->session->userdata('user_id');
        $arr['productvariation'] = $this->Product_model->show_productvariation($p_id);
        $this->load->view('frontend/header',$arr);
        $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/product',$arr);
    }

    public function reviews()
    {
        $user_id = $this->session->userdata('user_id'); //print_r($user_id);
        $data=array();
        // if($this->input->post('submit'))
        // {
            $email = $this->input->post('email');
            $message = $this->input->post('message');

            $this->form_validation->set_rules('email','Email Id','required');
            $this->form_validation->set_rules('message','message','required');

            if($this->form_validation->run()==FALSE)    
            { 
                $res = array(
                    'status' => "fail",
                    'message' => "registration fail"
                );

            }else{
                $data = array(
                    'user_id' => $user_id,
                    'email' => $email,
                    'message' => $message
                );
                //print_r($data); exit;
                $this->Product_model->review_insertdata($data);
                $res = array(
                    'status' => "success",
                    'message' => "Add to cart Successfully"
                );
                redirect('Product/product/');
            }
    }

    public function add_to_cart($product_id = null)
    { 
        $user_id = $this->session->userdata('user_id'); //print_r($user_id);
        $data=array();
        // if($this->input->post('submit'))
        // {
            
            $size = $this->input->post('size');
            $color = $this->input->post('color');
            $quantity = $this->input->post('quantity');
            $hide_price = $this->input->post('hide_price');

            // $this->form_validation->set_rules('size','Last Name','required');
            // $this->form_validation->set_rules('color','Company Name','required');
            // $this->form_validation->set_rules('quantity','Address','required');

            // if($this->form_validation->run()==FALSE)    
            // { 
            //     $res = array(
            //         'status' => "fail",
            //         'message' => "registration fail"
            //     );

            // }else{ 
                $data = array(
                    'user_id' => $user_id,
                    'product_id' => $product_id,
                    'quantity' => $quantity,
                    'size' => $size,
                    'color' => $color,
                    'total_price' => $hide_price
                );
                 $cart = $this->Product_model->show_cartdata($user_id); 
                 foreach($cart as $cartdata){  echo 'hii';
                    //echo '<pre>'; print_r($cartdata['product_id']);
                    if($cartdata['product_id'] == $data['product_id']){
                        redirect('Product/cart');
                    }else
                    {
                        $this->Product_model->cart_insertdata($data);
                        //redirect('Product/cart');
                    }
                }
                //$this->Product_model->cart_insertdata($data);
                $res = array(
                    'status' => "success",
                    'message' => "Add to cart Successfully"
                );
                redirect('Product/cart');
           // }
        // }
    } 

    public function cart()
    {
        $user_id = $this->session->userdata('user_id'); //print_r($user_id);
        $arr['cart'] = $this->Product_model->show_cartdata($user_id);
        $arr['cart_data'] = $this->Product_model->show_cartdatacount($user_id);
        $arr['shipping'] = $this->Product_model->show_shipping();//echo "<pre>"; print_r($arr); exit;
        $subcategories = $this->Home_model->show_subcategories();
        //echo '<pre>';print_r($arr['sub']);
        $arr['categories'] = $this->Home_model->showdata_categories();
        foreach ($subcategories as $subcat)
        {               
            $recent_subcategories[$subcat['categories_name']][$subcat['subc_id']] =  $subcat['subcategories_name'];
            // $recent_subcategories[$subcat->subcategories_name][] = $subcat->subcategories_name;
        }
        //echo "<pre>";print_r($recent_subcategories);
        $arr['subcategorie'] = $recent_subcategories;
        // $this->load->view('frontend/header',$arr);
        // $this->load->view('frontend/mobile_header',$arr);
        $this->load->view('frontend/cart',$arr);
    }

    function delete_cart($cart_id = null)
    {
        $this->Product_model->delete_cartdata($cart_id);
        redirect('Product/cart');
    }

    function update_quantity()
    { 
        $quantity = $_POST['quantity'];
        $id = $_POST['id'];
        $price = $_POST['price'];
        $total = $price * $quantity;
        $this->Product_model->updaterecords($id,$quantity,$total);
        echo $total;
    }
}