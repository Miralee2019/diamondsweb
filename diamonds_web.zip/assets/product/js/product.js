/*Size is  set in pixels... supports being written as: '250px' */
var magnifierSize = 200;

/*How many times magnification of image on page.*/
var magnification = 4;

function magnifier() {

  this.magnifyImg = function(ptr, magnification, magnifierSize) {
    var $pointer;
    if (typeof ptr == "string") {
      $pointer = $(ptr);
    } else if (typeof ptr == "object") {
      $pointer = ptr;
    }
    
    if(!($pointer.is('.lens img'))){
      alert('Object must be image.');
      return false;
    }

    magnification = +(magnification);

    $pointer.hover(function() {
      $(this).css('cursor', 'none');
      $('.magnify').show();
      //Setting some variables for later use
      var width = $(this).width();
      var height = $(this).height();
      var src = $(this).attr('src');
      var imagePos = $(this).offset();
      var image = $(this);

      if (magnifierSize == undefined) {
        magnifierSize = '150px';
      }

      $('.magnify').css({
        'background-size': width * magnification + 'px ' + height * magnification + "px",
        'background-image': 'url("' + src + '")',
        'width': magnifierSize,
        'height': magnifierSize
      });

      //Setting a few more...
      var magnifyOffset = +($('.magnify').width() / 2);
      var rightSide = +(imagePos.left + $(this).width());
      var bottomSide = +(imagePos.top + $(this).height());

      $(document).mousemove(function(e) {
        if (e.pageX < +(imagePos.left - magnifyOffset / 6) || e.pageX > +(rightSide + magnifyOffset / 6) || e.pageY < +(imagePos.top - magnifyOffset / 6) || e.pageY > +(bottomSide + magnifyOffset / 6)) {
          $('.magnify').hide();
          $(document).unbind('mousemove');
        }
        var backgroundPos = "" - ((e.pageX - imagePos.left) * magnification - magnifyOffset) + "px " + -((e.pageY - imagePos.top) * magnification - magnifyOffset) + "px";
        $('.magnify').css({
          'left': e.pageX - magnifyOffset,
          'top': e.pageY - magnifyOffset,
          'background-position': backgroundPos
        });
      });
    }, function() {

    });
  };

  this.init = function() {
    $('body').prepend('<div class="magnify"></div>');
  }

  return this.init();
}

var magnify = new magnifier();
magnify.magnifyImg('.lens img', magnification, magnifierSize);

$(document).ready(function () {

  $(".product_description .reviewlink").click(function(){
      $(".reviewdesc_section").addClass("active");
      $(".product_description .productdesc_section").css("display", "none");
      //$(".product_description .reviewlink").addClass("text_effect");
     // $(".product_description .reviewlink").css({"border-bottom": "1px solid #001a6f", "color": "#8c8c8c"});
      // if($(".reviewdesc_section").hasClass("active")){
      //   $(".product_description .reviewlink").addClass("text_effect");
      // }else{
      //   $(".product_description .reviewlink").removeClass("text_effect");
      // }
  });
  $(".product_description .desclink").click(function(){
    $(".reviewdesc_section").removeClass("active");
    $(".product_description .productdesc_section").css("display", "block");
    //$(".product_description .desclink").css({"border-bottom": "1px solid #001a6f", "color": "#8c8c8c"});
});

  $(window).scroll(function () {
    var height = $(window).scrollTop();
    if (height > 100) {
      $('#back2Top').fadeIn();
    } else {
      $('#back2Top').fadeOut();
    }
  });
  $("#back2Top").click(function (event) {
    event.preventDefault();
    $("html, body").animate({ scrollTop: 0 }, "slow");
    return false;
  });
  $(document).scroll(function () {
    var $nav = $("#mainNavbar");
    $nav.toggleClass("scrolled", $(this).scrollTop() > $nav.height());
  });

});
